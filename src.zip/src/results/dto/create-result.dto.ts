export class CreateResultDto {}
