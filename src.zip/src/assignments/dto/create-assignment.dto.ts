import { ApiProperty } from '@nestjs/swagger';
import { IsNotEmpty, IsString } from 'class-validator';

export class CreateAssignmentDto {
  @ApiProperty({ example: 'My answer to assignment' })
  @IsNotEmpty()
  @IsString()
  answer: string;
}
