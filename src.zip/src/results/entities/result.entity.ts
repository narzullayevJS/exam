export class Result {}
