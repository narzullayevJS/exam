import {
  Controller,
  Post,
  Param,
  Body,
  ParseIntPipe,
} from '@nestjs/common';
import { AssignmentsService } from './assignments.service';
import { CreateAssignmentDto } from './dto/create-assignment.dto';
import { CurrentUser } from '../auth/decarator/current-user.decorator';
import { User } from '../users/entities/user.entity';

@Controller('modules/:moduleId/assignment')
export class AssignmentsController {
  constructor(private readonly assignmentsService: AssignmentsService) {}

  // ✅ Talaba topshiriq yuboradi
  @Post()
  createAssignment(
    @Param('moduleId', ParseIntPipe) moduleId: number,
    @Body() dto: CreateAssignmentDto,
    @CurrentUser() user: User,
  ) {
    return this.assignmentsService.create(moduleId, dto, user);
  }
}
