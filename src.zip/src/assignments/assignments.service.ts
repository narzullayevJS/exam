import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';

import { Assignment } from './entities/assignment.entity';
import { Madule } from 'src/modules/entities/module.entity';
import { User } from 'src/users/entities/user.entity';
import { CreateAssignmentDto } from './dto/create-assignment.dto';

@Injectable()
export class AssignmentsService {
  constructor(
    @InjectRepository(Assignment)
    private assignmentRepo: Repository<Assignment>,

    @InjectRepository(Madule)
    private moduleRepo: Repository<Madule>,
  ) {}

  // ✅ Talaba topshiriq yaratadi
  async create(moduleId: number, dto: CreateAssignmentDto, student: User) {
    const module = await this.moduleRepo.findOne({ where: { id: moduleId } });

    if (!module) {
      throw new NotFoundException('Modul topilmadi');
    }

    const assignment = this.assignmentRepo.create({
      answer: dto.answer,
      module,
      student,
      status: 'pending',
    });

    return await this.assignmentRepo.save(assignment);
  }
}
