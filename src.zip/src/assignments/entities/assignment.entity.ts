import {
  Entity,
  Column,
  PrimaryGeneratedColumn,
  ManyToOne,
  CreateDateColumn,
} from 'typeorm';
import { User } from 'src/users/entities/user.entity';
import { Madule } from 'src/modules/entities/module.entity';

export type AssignmentStatus = 'pending' | 'graded';

@Entity()
export class Assignment {
  @PrimaryGeneratedColumn()
  id: number;

  @ManyToOne(() => User, (user) => user.assignments, { eager: false })
  student: User;

  @ManyToOne(() => Madule, (module) => module.assignments, { eager: false })
  module: Madule;

  @Column('text')
  answer: string;

  @Column({ type: 'int', nullable: true })
  score: number | null;

  @Column({ type: 'varchar', default: 'pending' })
  status: AssignmentStatus;

  @Column({ type: 'varchar', nullable: true })
  gradedBy: string | null;

  @CreateDateColumn()
  submittedAt: Date;
}
